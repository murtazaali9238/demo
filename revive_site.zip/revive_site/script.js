// Simple JS for menu + gallery lightbox
const menu = document.getElementById('menu');
const hamburger = document.querySelector('.hamburger');
if (hamburger) {
  hamburger.addEventListener('click', () => {
    const open = menu.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', String(open));
  });
}

const galleryGrid = document.getElementById('galleryGrid');
const makePlaceholder = (w, h, text) => {
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' width='${w}' height='${h}' aria-label='${text}'><rect width='100%' height='100%' fill='#eee'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-family='system-ui' font-size='16' fill='#666'>${text}</text></svg>`;
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
};

// Populate gallery with placeholders
const items = [
  'Sunbeds','Nails','Hair','Eyelashes','Pedicures','Body Piercing','Microblading','Make Up','Waxing & Threading'
];
items.forEach(label => {
  const img = document.createElement('img');
  img.src = makePlaceholder(600, 600, label);
  img.alt = label + ' example (demo image)';
  img.addEventListener('click', () => openLightbox(img.src));
  galleryGrid.appendChild(img);
});

// Lightbox
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const closeBtn = document.getElementById('closeLightbox');
function openLightbox(src) {
  lightboxImg.src = src;
  if (typeof lightbox.showModal === 'function') {
    lightbox.showModal();
  } else {
    lightbox.setAttribute('open','');
  }
}
closeBtn.addEventListener('click', () => lightbox.close());
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) lightbox.close();
});
